#include <stdio.h>
#include <stdlib.h>

/* klavyeden girilen say�n�n tam b�lenlerini bulan program� kodlay�n */



int main() {
	
	int sayi,i;
	printf("Sayiyi girin:");
	scanf("%d",&sayi);
	
	for(i=1;i<=sayi;i++){
		
		if(sayi%i==0){
			printf("%d\n",i);
		}
	}
	
	
	
	
	
	
	return 0;
}
