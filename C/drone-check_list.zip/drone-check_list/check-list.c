#include <stdio.h>
#include <stdlib.h>



int main() {

	printf("*************Check_list Kontrol Sistemi*************");
	printf("\n\n");
	
	int a,sayi;
   	
   	printf("Evet icin ==> 1 \n");
   	printf("Hayir icin ==> 0 \n");
   	printf("\n\n");
   	
   	
   	printf("Ucus izni alindi mi?\n\n");
	scanf("%d",&sayi);
	switch(sayi){
		
		case 0:
			printf("Hayir izin alinmadi.\n");
			a=0;
			break;
		
		case 1:
			printf("Evet izin alindi.\n");
			a=1;
			break;
			
		default:printf("hatali tusa bastiniz\n");
			
		}
		
		printf("Ruzgarin hizi kabul edilebilir seviyede mi kontrol edildi mi?\n\n");
	scanf("%d",&sayi);
	switch(sayi){
		
		case 0:
			printf("Kontrol edilmedi.\n");
			a=0;
			break;
		
		case 1:
			printf("Kontrol edildi.\n");
			a=1;
			break;
			
		default:printf("hatali tusa bastiniz\n");
			
		}
		
		printf("Ucus bolgesinde yagis bekleniyor mu kontrol edildi mi?\n\n");
	scanf("%d",&sayi);
	switch(sayi){
		
		case 0:
			printf("Kontrol edilmedi.\n");
			a=0;
			break;
		
		case 1:
			printf("Kontrol edildi.\n");
			a=1;
			break;
			
		default:printf("hatali tusa bastiniz\n");
			
		}
		
		printf("Ucus bolgesinde gorus yeterli mi kontrol edildi mi?\n\n");
	scanf("%d",&sayi);
	switch(sayi){
		
		case 0:
			printf("Kontrol edilmedi.\n");
			a=0;
			break;
		
		case 1:
			printf("Kontrol edildi.\n");
			a=1;
			break;
			
		default:printf("hatali tusa bastiniz\n");
			
		}

	printf("******Ucus bilgileriyle ilgili kontroller******");
	printf("\n\n");
	printf("Bir IHA pilotu, ucus operasyonundan once asagida belirtilen bilgileri yazili olarak kayit altina almalidir.\n\n");
	
	printf("Pilotun adi,soyadi yazildi mi?\n");
		scanf("%d",&sayi);
	switch(sayi){
		
		case 1:
			printf("Evet\n");
			a=1;
			break;
		
		case 0:
			printf("Hayir\n");
			a=0;
			break;
			
		default:printf("hatali tusa bastiniz\n");
			
		}

printf("IHA tescil numarasi yazildi mi?\n");
		scanf("%d",&sayi);
	switch(sayi){
		
		case 1:
			printf("Evet\n");
			a=1;
			break;
		
		case 0:
			printf("Hayir\n");
			a=0;
			break;
			
		default:printf("hatali tusa bastiniz\n");
			
		}
		
printf("Ucus tarihi yazildi mi?\n");
		scanf("%d",&sayi);
	switch(sayi){
		
		case 1:
			printf("Evet\n");
			a=1;
			break;
		
		case 0:
			printf("Hayir\n");
			a=0;
			break;
			
		default:printf("hatali tusa bastiniz\n");
			
		}
		
printf("Ucus bolgesi yazildi mi?\n");
		scanf("%d",&sayi);
	switch(sayi){
		
		case 1:
			printf("Evet\n");
			a=1;
			break;
		
		case 0:
			printf("Hayir\n");
			a=0;
			break;
			
		default:printf("hatali tusa bastiniz\n");
			
		}

printf("IHA model adi yazildi mi?\n");
		scanf("%d",&sayi);
	switch(sayi){
		
		case 1:
			printf("Evet\n");
			a=1;
			break;
		
		case 0:
			printf("Hayir\n");
			a=0;
			break;
			
		default:printf("hatali tusa bastiniz\n");
			
		}

printf("IHA model numarasi yazildi mi?\n");
		scanf("%d",&sayi);
	switch(sayi){
		
		case 1:
			printf("Evet\n");
			a=1;
			break;
		
		case 0:
			printf("Hayir\n");
			a=0;
			break;
			
		default:printf("hatali tusa bastiniz\n");
			
		}
		
printf("IHA ID numarasi (serial) yazildi mi?\n");
		scanf("%d",&sayi);
	switch(sayi){
		
		case 1:
			printf("Evet\n");
			a=1;
			break;
		
		case 0:
			printf("Hayir\n");
			a=0;
			break;
			
		default:printf("hatali tusa bastiniz\n");
			
		}

printf("IHA nin agirligi yazildi mi?\n");
		scanf("%d",&sayi);
	switch(sayi){
		
		case 1:
			printf("Evet\n");
			a=1;
			break;
		
		case 0:
			printf("Hayir\n");
			a=0;
			break;
			
		default:printf("hatali tusa bastiniz\n");
			
		}

printf("Ucus gerekcesi yazildi mi?\n");
		scanf("%d",&sayi);
	switch(sayi){
		
		case 1:
			printf("Evet\n");
			a=1;
			break;
		
		case 0:
			printf("Hayir\n");
			a=0;
			break;
			
		default:printf("hatali tusa bastiniz\n");
			
		}

printf("IHA pilotunun lisans dururmu yazildi mi?\n");
		scanf("%d",&sayi);
	switch(sayi){
		
		case 1:
			printf("Evet\n");
			a=1;
			break;
		
		case 0:
			printf("Hayir\n");
			a=0;
			break;
			
		default:printf("hatali tusa bastiniz\n");
			
		}
		
printf("Ucus izin durumu yazildi mi?\n");
		scanf("%d",&sayi);
	switch(sayi){
		
		case 1:
			printf("Evet\n");
			a=1;
			break;
		
		case 0:
			printf("Hayir\n");
			a=0;
			break;
			
		default:printf("hatali tusa bastiniz\n");
			
		}



printf("IHA nin ve kontrol unitesinin pilleri en az %75 seviyesinde doluluk kontol� yapildi mi?\n");
		scanf("%d",&sayi);
	switch(sayi){
		
		case 1:
			printf("Evet\n");
			a=1;
			break;
		
		case 0:
			printf("Hayir\n");
			a=0;
			break;
			
		default:printf("hatali tusa bastiniz\n");
			
		}

printf("IHA nin ve kontrol unitesinin yedek pilleri en az %75 seviyesinde doluluk kontol� yapildi mi?\n");
		scanf("%d",&sayi);
	switch(sayi){
		
		case 1:
			printf("Evet\n");
			a=1;
			break;
		
		case 0:
			printf("Hayir\n");
			a=0;
			break;
			
		default:printf("hatali tusa bastiniz\n");
			
		}

printf("IHA nin ve kontrol unitesinin pilleri arac uzerindeki konumunda dogru, emniyetli bir bicimde sabitlendi mi?\n");
		scanf("%d",&sayi);
	switch(sayi){
		
		case 1:
			printf("Evet\n");
			a=1;
			break;
		
		case 0:
			printf("Hayir\n");
			a=0;
			break;
			
		default:printf("hatali tusa bastiniz\n");
			
		}





		printf("\n\n\n\n\n\n\n\n\n\n\n");
		
		printf("****************Kontrol edelim*********************\n\n\n");
		
		printf("Ucus izni alindi mi?\n");
		 if(a=0){
	   	printf("Hayir\n");
	   }
	   if(a=1){
	   		printf("Evet\n");
	   }
	   
	   	printf("Ruzgarin hizi kabul edilebilir seviyede mi kontrol edildi mi?\n");
		 if(a=0){
	   	printf("Hayir\n");
	   }
	   if(a=1){
	   		printf("Evet\n");
	   }
	   
	    
		printf("Ucus bolgesinde yagis bekleniyor mu kontrol edildi mi?\n");
		 if(a=0){
	   	printf("Hayir\n");
	   }
	   if(a=1){
	   		printf("Evet\n");
	   }
	   
	    
			printf("Ucus bolgesinde gorus yeterli mi kontrol edildi mi?\n");
		 if(a=0){
	   	printf("Hayir\n");
	   }
	   if(a=1){
	   		printf("Evet\n");
	   }
		
			printf("Pilotun adi,soyadi yazildi mi?\n");
		 if(a=0){
	   	printf("Hayir\n");
	   }
	   if(a=1){
	   		printf("Evet\n");
	   }
		
		printf("IHA tescil numarasi yazildi mi?\n");
			 if(a=0){
	   	printf("Hayir\n");
	   }
	   if(a=1){
	   		printf("Evet\n");
	   }
	   
	   printf("Ucus tarihi yazildi mi?\n");
			 if(a=0){
	   	printf("Hayir\n");
	   }
	   if(a=1){
	   		printf("Evet\n");
	   }
	   
	   printf("Ucus bolgesi yazildi mi?\n");
			 if(a=0){
	   	printf("Hayir\n");
	   }
	   if(a=1){
	   		printf("Evet\n");
	   }
	   
	   printf("IHA model adi yazildi mi?\n");
			 if(a=0){
	   	printf("Hayir\n");
	   }
	   if(a=1){
	   		printf("Evet\n");
	   }
		
		 printf("IHA model numarasi yazildi mi?\n");
			 if(a=0){
	   	printf("Hayir\n");
	   }
	   if(a=1){
	   		printf("Evet\n");
	   }
	   
	   	 printf("IHA model numarasi yazildi mi?\n");
			 if(a=0){
	   	printf("Hayir\n");
	   }
	   if(a=1){
	   		printf("Evet\n");
	   }
		
		printf("IHA ID numarasi (serial) yazildi mi?\n");
			 if(a=0){
	   	printf("Hayir\n");
	   }
	   if(a=1){
	   		printf("Evet\n");
	   }
	   
		printf("IHA nin agirligi yazildi mi?\n");
	 if(a=0){
	   	printf("Hayir\n");
	   }
	   if(a=1){
	   		printf("Evet\n");
	   }
	   
	   	printf("IHA nin agirligi yazildi mi?\n");
	 if(a=0){
	   	printf("Hayir\n");
	   }
	   if(a=1){
	   		printf("Evet\n");
	   }
	   
	     	printf("IHA pilotunun lisans dururmu yazildi mi?\n");
	 if(a=0){
	   	printf("Hayir\n");
	   }
	   if(a=1){
	   		printf("Evet\n");
	   }
	   
	      	printf("Ucus izin durumu yazildi mi?\n");
	 if(a=0){
	   	printf("Hayir\n");
	   }
	   if(a=1){
	   		printf("Evet\n");
	   }
	   
	       	printf("IHA nin ve kontrol unitesinin pilleri en az %75 seviyesinde doluluk kontol� yapildi mi?\n");
	 if(a=0){
	   	printf("Hayir\n");
	   }
	   if(a=1){
	   		printf("Evet\n");
	   }
	   
	        	printf("IHA nin ve kontrol unitesinin yedek pilleri en az %75 seviyesinde doluluk kontol� yapildi mi?\n");
	 if(a=0){
	   	printf("Hayir\n");
	   }
	   if(a=1){
	   		printf("Evet\n");
	   }
	   
	   
	      	printf("IHA nin ve kontrol unitesinin pilleri arac uzerindeki konumunda dogru, emniyetli bir bicimde sabitlendi mi?\n");
	 if(a=0){
	   	printf("Hayir\n");
	   }
	   if(a=1){
	   		printf("Evet\n");
	   }
	   
	        	printf("IHA nin ve kontrol unitesinin pilleri arac uzerindeki konumunda dogru, emniyetli bir bicimde sabitlendi mi?\n");
	        	
	 if(a=0){
	   	printf("Hayir\n");
	   }
	   if(a=1){
	   		printf("Evet\n");
	   }
	   
	   
	   
	return 0;
	}      	
   	
